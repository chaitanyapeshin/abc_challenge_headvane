# Model comparison — 9th ABC Challenge head-pose prediction

All models scored on the **same 46,474 test windows** from **1,330 held-out users** (never used for training or model selection), through each run's packaged `model_fp32.onnx`, on this CPU with 1 thread. Score = mean of 2·acos(|q̂·q|) at the 20th predicted sample (200 ms ahead).

| model | mean @200 ms (SCORE, °) | mean @100 ms (°) | median @200 ms (°) | p95 @200 ms (°) | vs constant velocity | vs damped velocity | parameters | MACs per call | ONNX ms/call (this CPU) | context (samples) | ops outside safe list | rank score (0 = best) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| last orientation | 6.618 | 3.777 | 5.094 | 16.815 | -11.5 % | +18.5 % | 0 | 0 | — | 1 | — | — |
| constant velocity | 7.479 | 3.227 | 5.710 | 19.193 | +0.0 % | +33.9 % | 0 | 620 | — | 2 | — | — |
| damped velocity | 5.584 | 2.771 | 4.372 | 13.948 | -25.3 % | +0.0 % | 2 | 680 | — | 2 | — | — |
| GRU | 4.639 | 2.787 | 3.693 | 11.367 | -38.0 % | -16.9 % | 66,448 | 4,925,288 | 0.324 | 100 | 18 | 0.156 |
| TCN | 4.702 | 2.787 | 3.734 | 11.512 | -37.1 % | -15.8 % | 49,456 | 3,685,672 | 0.242 | 100 | 18 | 0.406 |
| LSTM | 4.676 | 2.787 | 3.703 | 11.460 | -37.5 % | -16.3 % | 83,088 | 6,547,304 | 0.345 | 100 | 18 | 0.406 |
| SSM | 4.688 | 2.787 | 3.714 | 11.519 | -37.3 % | -16.0 % | 33,552 | 2,124,776 | 0.392 | 100 | 18 | 0.531 |
| KalmanNet | 5.131 | 2.581 | 4.020 | 12.741 | -31.4 % | -8.1 % | 139,764 | 13,734,700 | 7.090 | 100 | 17 | 1.000 |

## How to read it

* **mean @200 ms** is what the challenge scores for accuracy (40 %) — **lower is better**.
* **vs damped velocity** is the honest bar: damped velocity is a 2-number baseline any team can build. A learned model is only worth its cost if it beats it clearly (see the bootstrap lines below).
* **ONNX ms/call** and **parameters** feed the latency (30 %) and parameter (10 %) criteria — **lower is better**. Latency here is this machine's CPU; the organisers' XR hardware is slower, but the ranking usually holds.
* **rank score** imitates the challenge: each criterion ranked among our models (0 = best), weighted 40/30/10. Innovation (20 %) is judged from the paper and is not included. The lowest rank score is the strongest submission candidate *among these models*; the real ranking depends on the other teams.

**Best by rank score:** GRU (0.16). **Most accurate:** GRU (4.639°).

## Is the difference real? (per-user bootstrap, 95 % intervals in degrees)

* damped velocity − last orientation: [-1.079, -0.989] → worse than damped velocity
* last orientation − GRU (best): [+1.921, +2.047] → GRU clearly better
* damped velocity − constant velocity: [-1.977, -1.812] → worse than damped velocity
* constant velocity − GRU (best): [+2.743, +2.932] → GRU clearly better
* damped velocity − GRU (best): [+0.911, +0.984] → GRU clearly better
* damped velocity − GRU: [+0.911, +0.984] → better than damped velocity
* damped velocity − TCN: [+0.847, +0.918] → better than damped velocity
* TCN − GRU (best): [+0.054, +0.072] → GRU clearly better
* damped velocity − LSTM: [+0.874, +0.945] → better than damped velocity
* LSTM − GRU (best): [+0.030, +0.046] → GRU clearly better
* damped velocity − SSM: [+0.863, +0.932] → better than damped velocity
* SSM − GRU (best): [+0.041, +0.057] → GRU clearly better
* damped velocity − KalmanNet: [+0.433, +0.472] → better than damped velocity
* KalmanNet − GRU (best): [+0.469, +0.518] → GRU clearly better

## Error by head speed

```
               share_%  last orientation  constant velocity  damped velocity     GRU     TCN    LSTM     SSM  KalmanNet
still <5°/s      1.448             2.194              2.180            2.147   1.995   2.028   2.005   2.028      2.131
slow 5–50       67.517             4.962              5.242            4.369   3.830   3.870   3.849   3.869      4.093
moving 50–150   28.952             9.669             11.459            7.810   6.136   6.256   6.195   6.208      7.012
fast >150        2.083            20.964             28.375           16.434  11.873  11.939  12.252  11.953     14.752
```

## Error by predictability (entropy classes, Zhong et al. 2025)

```
        last orientation  constant velocity  damped velocity    GRU    TCN   LSTM    SSM  KalmanNet
easy               4.914              5.922            4.286  3.600  3.646  3.621  3.643      3.961
medium             6.211              7.063            5.270  4.387  4.443  4.414  4.428      4.835
hard               8.728              9.454            7.198  5.930  6.017  5.994  5.994      6.599
```

![](fig_comparison.png)

* damped velocity: β=0.9, k=1 (tuned on train users)
