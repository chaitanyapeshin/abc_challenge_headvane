# Model comparison — 9th ABC Challenge head-pose prediction

All models scored on the **same 46,474 test windows** from **1,330 held-out users** (never used for training or model selection), through each run's packaged `model_fp32.onnx`, on this CPU with 1 thread. Score = mean of 2·acos(|q̂·q|) at the 20th predicted sample (200 ms ahead).

| model | mean @200 ms (SCORE, °) | mean @100 ms (°) | median @200 ms (°) | p95 @200 ms (°) | vs constant velocity | vs damped velocity | parameters | MACs per call | ONNX ms/call (this CPU) | context (samples) | ops outside safe list | rank score (0 = best) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| last orientation | 6.618 | 3.777 | 5.094 | 16.815 | -11.5 % | +18.5 % | 0 | 0 | — | 1 | — | — |
| constant velocity | 7.479 | 3.227 | 5.710 | 19.193 | +0.0 % | +33.9 % | 0 | 620 | — | 2 | — | — |
| damped velocity | 5.584 | 2.771 | 4.372 | 13.948 | -25.3 % | +0.0 % | 2 | 680 | — | 2 | — | — |
| GRU | 4.639 | 2.787 | 3.693 | 11.367 | -38.0 % | -16.9 % | 66,448 | 4,925,288 | 0.329 | 100 | 18 | 0.426 |
| TCN | 4.702 | 2.787 | 3.734 | 11.512 | -37.1 % | -15.8 % | 49,456 | 3,685,672 | 0.247 | 100 | 18 | 0.430 |
| LSTM | 4.676 | 2.787 | 3.703 | 11.460 | -37.5 % | -16.3 % | 83,088 | 6,547,304 | 0.339 | 100 | 18 | 0.516 |
| SSM | 4.688 | 2.787 | 3.714 | 11.519 | -37.3 % | -16.0 % | 33,552 | 2,124,776 | 0.401 | 100 | 18 | 0.531 |
| Transformer | 4.554 | 2.257 | 3.636 | 11.162 | -39.1 % | -18.5 % | 121,892 | 2,202,344 | 0.245 | 100 | 19 | 0.176 |
| PoseGRT | 4.413 | 2.203 | 3.518 | 10.750 | -41.0 % | -21.0 % | 1,338,437 | 78,200,856 | 2.110 | 200 | 21 | 0.477 |
| KalmanNet | 5.131 | 2.581 | 4.020 | 12.741 | -31.4 % | -8.1 % | 139,764 | 13,734,700 | 7.424 | 100 | 17 | 0.938 |
| ControlledResidual [controlled_residual] | 4.788 | 2.417 | 3.786 | 11.745 | -36.0 % | -14.3 % | 270,336 | 2,093,280 | 0.924 | 100 | 25 | 0.797 |
| GRU [gru128_aux] | 4.573 | 2.265 | 3.639 | 11.209 | -38.9 % | -18.1 % | 223,312 | 19,569,640 | 0.769 | 100 | 18 | 0.488 |
| GRU [gru128_aux_context_200] | 4.506 | 2.246 | 3.579 | 11.068 | -39.7 % | -19.3 % | 223,312 | 39,312,040 | 1.430 | 200 | 18 | 0.465 |
| GRU [gru_aux] | 4.635 | 2.301 | 3.690 | 11.358 | -38.0 % | -17.0 % | 66,448 | 4,925,288 | 0.332 | 100 | 18 | 0.418 |
| GRU [gru_raw] | 4.630 | 2.332 | 3.676 | 11.360 | -38.1 % | -17.1 % | 66,320 | 4,912,616 | 0.277 | 100 | 17 | 0.305 |
| MOUNT | 4.598 | 2.250 | 3.658 | 11.257 | -38.5 % | -17.7 % | 294,312 | 20,368,688 | 0.815 | 100 | 21 | 0.563 |
| QuaterNet | 4.903 | 2.463 | 3.883 | 12.009 | -34.4 % | -12.2 % | 151,300 | 17,747,488 | 1.612 | 100 | 19 | 0.836 |
| Transformer [transformer_40k] | 4.517 | 2.237 | 3.608 | 11.093 | -39.6 % | -19.1 % | 121,892 | 2,202,344 | 0.246 | 100 | 19 | 0.168 |
| Transformer [transformer_best] | 4.475 | 2.235 | 3.558 | 10.896 | -40.2 % | -19.9 % | 156,644 | 6,213,544 | 0.403 | 200 | 19 | 0.328 |
| Transformer [transformer_raw] | 5.031 | 2.567 | 3.991 | 12.340 | -32.7 % | -9.9 % | 154,328 | 6,138,280 | 0.321 | 200 | 17 | 0.641 |

## How to read it

* **mean @200 ms** is what the challenge scores for accuracy (40 %) — **lower is better**.
* **vs damped velocity** is the honest bar: damped velocity is a 2-number baseline any team can build. A learned model is only worth its cost if it beats it clearly (see the bootstrap lines below).
* **ONNX ms/call** and **parameters** feed the latency (30 %) and parameter (10 %) criteria — **lower is better**. Latency here is this machine's CPU; the organisers' XR hardware is slower, but the ranking usually holds.
* **rank score** imitates the challenge: each criterion ranked among our models (0 = best), weighted 40/30/10. Innovation (20 %) is judged from the paper and is not included. The lowest rank score is the strongest submission candidate *among these models*; the real ranking depends on the other teams.

**Best by rank score:** Transformer [transformer_40k] (0.17). **Most accurate:** PoseGRT (4.413°).

## Is the difference real? (per-user bootstrap, 95 % intervals in degrees)

* damped velocity − last orientation: [-1.079, -0.990] → worse than damped velocity
* last orientation − PoseGRT (best): [+2.137, +2.276] → PoseGRT clearly better
* damped velocity − constant velocity: [-1.968, -1.814] → worse than damped velocity
* constant velocity − PoseGRT (best): [+2.966, +3.159] → PoseGRT clearly better
* damped velocity − PoseGRT (best): [+1.129, +1.217] → PoseGRT clearly better
* damped velocity − GRU: [+0.908, +0.983] → better than damped velocity
* GRU − PoseGRT (best): [+0.211, +0.242] → PoseGRT clearly better
* damped velocity − TCN: [+0.847, +0.917] → better than damped velocity
* TCN − PoseGRT (best): [+0.273, +0.307] → PoseGRT clearly better
* damped velocity − LSTM: [+0.874, +0.944] → better than damped velocity
* LSTM − PoseGRT (best): [+0.246, +0.281] → PoseGRT clearly better
* damped velocity − SSM: [+0.862, +0.932] → better than damped velocity
* SSM − PoseGRT (best): [+0.259, +0.292] → PoseGRT clearly better
* damped velocity − Transformer: [+0.991, +1.070] → better than damped velocity
* Transformer − PoseGRT (best): [+0.130, +0.153] → PoseGRT clearly better
* damped velocity − PoseGRT: [+1.129, +1.217] → better than damped velocity
* damped velocity − KalmanNet: [+0.433, +0.472] → better than damped velocity
* KalmanNet − PoseGRT (best): [+0.687, +0.751] → PoseGRT clearly better
* damped velocity − ControlledResidual [controlled_residual]: [+0.761, +0.832] → better than damped velocity
* ControlledResidual [controlled_residual] − PoseGRT (best): [+0.355, +0.396] → PoseGRT clearly better
* damped velocity − GRU [gru128_aux]: [+0.973, +1.050] → better than damped velocity
* GRU [gru128_aux] − PoseGRT (best): [+0.146, +0.174] → PoseGRT clearly better
* damped velocity − GRU [gru128_aux_context_200]: [+1.038, +1.116] → better than damped velocity
* GRU [gru128_aux_context_200] − PoseGRT (best): [+0.082, +0.105] → PoseGRT clearly better
* damped velocity − GRU [gru_aux]: [+0.912, +0.986] → better than damped velocity
* GRU [gru_aux] − PoseGRT (best): [+0.207, +0.237] → PoseGRT clearly better
* damped velocity − GRU [gru_raw]: [+0.916, +0.993] → better than damped velocity
* GRU [gru_raw] − PoseGRT (best): [+0.200, +0.235] → PoseGRT clearly better
* damped velocity − MOUNT: [+0.947, +1.025] → better than damped velocity
* MOUNT − PoseGRT (best): [+0.171, +0.199] → PoseGRT clearly better
* damped velocity − QuaterNet: [+0.651, +0.713] → better than damped velocity
* QuaterNet − PoseGRT (best): [+0.468, +0.513] → PoseGRT clearly better
* damped velocity − Transformer [transformer_40k]: [+1.026, +1.108] → better than damped velocity
* Transformer [transformer_40k] − PoseGRT (best): [+0.094, +0.115] → PoseGRT clearly better
* damped velocity − Transformer [transformer_best]: [+1.069, +1.152] → better than damped velocity
* Transformer [transformer_best] − PoseGRT (best): [+0.053, +0.070] → PoseGRT clearly better
* damped velocity − Transformer [transformer_raw]: [+0.524, +0.584] → better than damped velocity
* Transformer [transformer_raw] − PoseGRT (best): [+0.592, +0.644] → PoseGRT clearly better

## Error by head speed

```
               share_%  last orientation  constant velocity  damped velocity     GRU     TCN    LSTM     SSM  Transformer  PoseGRT  KalmanNet  ControlledResidual [controlled_residual]  GRU [gru128_aux]  GRU [gru128_aux_context_200]  GRU [gru_aux]  GRU [gru_raw]   MOUNT  QuaterNet  Transformer [transformer_40k]  Transformer [transformer_best]  Transformer [transformer_raw]
still <5°/s      1.448             2.194              2.180            2.147   1.995   2.028   2.005   2.028        1.971    1.943      2.131                                     2.075             1.965                         1.965          1.995          1.991   2.000      2.133                          1.957                           1.959                          2.083
slow 5–50       67.517             4.962              5.242            4.369   3.830   3.870   3.849   3.869        3.778    3.680      4.093                                     3.926             3.790                         3.736          3.828          3.802   3.809      4.028                          3.761                           3.719                          4.052
moving 50–150   28.952             9.669             11.459            7.810   6.136   6.256   6.195   6.208        6.022    5.814      7.012                                     6.354             6.030                         5.937          6.129          6.151   6.088      6.535                          5.965                           5.915                          6.825
fast >150        2.083            20.964             28.375           16.434  11.873  11.939  12.252  11.953       11.093   10.394     14.752                                    12.881            11.522                        11.350         11.859         12.160  11.273     12.530                         10.710                          10.707                         13.866
```

## Error by predictability (entropy classes, Zhong et al. 2025)

```
        last orientation  constant velocity  damped velocity    GRU    TCN   LSTM    SSM  Transformer  PoseGRT  KalmanNet  ControlledResidual [controlled_residual]  GRU [gru128_aux]  GRU [gru128_aux_context_200]  GRU [gru_aux]  GRU [gru_raw]  MOUNT  QuaterNet  Transformer [transformer_40k]  Transformer [transformer_best]  Transformer [transformer_raw]
easy               4.914              5.922            4.286  3.600  3.646  3.621  3.643        3.552    3.458      3.961                                     3.703             3.553                         3.516          3.598          3.616  3.569      3.791                          3.524                           3.504                          3.909
medium             6.211              7.063            5.270  4.387  4.443  4.414  4.428        4.313    4.191      4.835                                     4.519             4.330                         4.264          4.384          4.376  4.355      4.620                          4.286                           4.245                          4.755
hard               8.728              9.454            7.198  5.930  6.017  5.994  5.994        5.797    5.589      6.599                                     6.143             5.836                         5.739          5.924          5.899  5.870      6.299                          5.742                           5.676                          6.429
```

![](fig_comparison.png)

* damped velocity: β=0.9, k=1 (tuned on train users)
