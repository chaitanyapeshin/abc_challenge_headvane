#!/usr/bin/env python
"""make_paper_figures.py — publication figures (IEEE column width) from compare_all.py outputs.

    python make_paper_figures.py --comparison comparison --out paper_figs --submitted "Transformer"

Reads comparison/{comparison.csv, per_horizon.csv, by_regime.csv, by_predictability.csv} and writes
vector PDFs: fig_tradeoff.pdf, fig_horizon.pdf, fig_regime.pdf (+ fig_predictability.pdf if present).
"""
import argparse
from pathlib import Path

import matplotlib
import matplotlib.ticker
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams.update({"font.size": 7, "axes.labelsize": 7, "legend.fontsize": 6, "xtick.labelsize": 6,
                     "ytick.labelsize": 6, "font.family": "serif", "axes.grid": True, "grid.alpha": 0.3,
                     "pdf.fonttype": 42, "lines.linewidth": 1.0, "lines.markersize": 3})
COL = 3.45                                             # IEEE single-column width, inches
BASELINES = ["last orientation", "constant velocity", "damped velocity"]
OFFSETS = {"GRU": (-5, -2, "right"), "LSTM": (0, 6, "center"), "SSM": (5, -1, "left"), "TCN": (0, 6, "center"),
           "Transformer [transformer_40k]": (0, -11, "center"), "Transformer [transformer_best]": (5, -3, "left"),
           "MOUNT": (5, -1, "left"), "GRU [gru128_aux_context_200]": (5, 2, "left"), "PoseGRT": (5, -3, "left"),
           "ControlledResidual [controlled_residual]": (5, 0, "left"), "QuaterNet": (5, 0, "left"),
           "KalmanNet": (-5, 4, "right")}   # label placement (points, alignment)


NAMES = {"Transformer [transformer_40k]": "Ours (Transformer)", "Transformer [transformer_best]": "Transformer-L",
         "GRU [gru128_aux_context_200]": "GRU-128 (ctx 200)", "GRU [gru128_aux]": "GRU-128",
         "ControlledResidual [controlled_residual]": "Ctrl. residual", "GRU [gru_aux]": "GRU",
         "GRU [gru_raw]": "GRU (raw input)", "Transformer [transformer_raw]": "Transformer-L (raw input)"}
TRADEOFF = ["GRU", "TCN", "LSTM", "SSM", "Transformer [transformer_40k]", "Transformer [transformer_best]", "PoseGRT",
            "KalmanNet", "MOUNT", "QuaterNet", "ControlledResidual [controlled_residual]", "GRU [gru128_aux_context_200]"]


COLORS = {"last orientation": "#8C8C8C", "constant velocity": "#DD8452", "damped velocity": "#4C72B0",
          "GRU [gru_aux]": "#55A868", "PoseGRT": "#8172B3"}


def short(n):
    return NAMES.get(n, n)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--comparison", default="comparison")
    ap.add_argument("--out", default="paper_figs")
    ap.add_argument("--submitted", default="Transformer [transformer_40k]", help="row of the submitted model (highlighted)")
    ap.add_argument("--horizon-models", nargs="*", default=["last orientation", "constant velocity", "damped velocity",
                                                            "GRU [gru_aux]", "Transformer [transformer_40k]", "PoseGRT"])
    a = ap.parse_args()
    src, out = Path(a.comparison), Path(a.out); out.mkdir(parents=True, exist_ok=True)
    t = pd.read_csv(src / "comparison.csv", index_col=0)
    score, ms = "mean @200 ms (SCORE, °)", "ONNX ms/call (this CPU)"

    # 1) accuracy vs latency, marker area ~ parameters
    m = t.loc[[n for n in TRADEOFF if n in t.index]]
    fig, ax = plt.subplots(figsize=(COL, 2.2))
    for n, r in m.iterrows():
        c = "#C44E52" if n == a.submitted else "#4C72B0"
        ax.scatter(r[ms], r[score], s=8 + 40 * np.log10(r["parameters"] / 1e4 + 1), color=c, alpha=0.8, zorder=3)
        dx, dy, ha = OFFSETS.get(n, (3, 2, "left"))
        ax.annotate(short(n), (r[ms], r[score]), fontsize=5, xytext=(dx, dy), textcoords="offset points", ha=ha,
                    color="#C44E52" if n == a.submitted else "black", fontweight="bold" if n == a.submitted else None)
    ax.axhline(t.loc["damped velocity", score], color="gray", ls=":", lw=0.8)
    ax.text(m[ms].max(), t.loc["damped velocity", score], "damped velocity", fontsize=5, ha="right", va="bottom", color="gray")
    ax.set_xscale("log")
    ticks = [x for x in (0.2, 0.3, 0.5, 1, 2, 5, 10) if m[ms].min() / 1.5 <= x <= m[ms].max() * 1.5]
    ax.xaxis.set_major_locator(matplotlib.ticker.FixedLocator(ticks))
    ax.xaxis.set_major_formatter(matplotlib.ticker.FixedFormatter([f"{x:g}" for x in ticks]))
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlabel("ONNX latency per call (ms, CPU, 1 thread)"); ax.set_ylabel("mean error @200 ms (°)")
    fig.tight_layout(pad=0.3); fig.savefig(out / "fig_tradeoff.pdf"); plt.close(fig)

    # 2) error vs horizon
    if (src / "per_horizon.csv").exists():
        h = pd.read_csv(src / "per_horizon.csv", index_col=0)
        fig, ax = plt.subplots(figsize=(COL, 2.0))
        for n in a.horizon_models:
            if n in h:
                ax.plot(h.index, h[n], marker="." if n not in BASELINES else None, ls="--" if n in BASELINES else "-",
                        label=short(n), color=COLORS.get(n, "#C44E52" if n == a.submitted else None))
        ax.set_xlabel("prediction horizon (ms)"); ax.set_ylabel("mean geodesic error (°)"); ax.legend(ncol=2)
        fig.tight_layout(pad=0.3); fig.savefig(out / "fig_horizon.pdf"); plt.close(fig)

    # 3) error by head speed (and predictability)
    for fname, label in (("by_regime.csv", "head speed at prediction time"), ("by_predictability.csv", "predictability class")):
        if not (src / fname).exists():
            continue
        r = pd.read_csv(src / fname, index_col=0).drop(columns=["share_%"], errors="ignore")
        cols = [c for c in ["damped velocity", "GRU [gru_aux]", "PoseGRT", a.submitted] if c in r]
        fig, ax = plt.subplots(figsize=(COL, 1.9))
        r[cols].rename(columns=short).plot.bar(ax=ax, rot=0, width=0.75)
        ax.set_xlabel(label); ax.set_ylabel("mean error @200 ms (°)"); ax.legend(ncol=2)
        fig.tight_layout(pad=0.3); fig.savefig(out / ("fig_regime.pdf" if "regime" in fname else "fig_predictability.pdf"))
        plt.close(fig)
    print("figures written to", out.resolve())


if __name__ == "__main__":
    main()
